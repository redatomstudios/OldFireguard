<?php include("header.php"); ?>
<link href="ControlPanel.css" rel="stylesheet">
<div class="bodyContainer">
<div id="headerText">Manager Control Panel</div>
<p>
Welcome <?php 
echo $_SESSION['name'].",";
echo "<br />Manager ID: ".$_SESSION['mid'];

?>
</p>

	<?php
    
    include ('mysql_include.php');
    $query="select fname,minit,lname,jobtitle,eid from employee where mid LIKE '".$_SESSION['mid']."' AND mempending=1;";
    $res=mysql_query($query);
    if($res && mysql_num_rows($res) != 0)
    { 
			echo "<div class='box' id='empApprove'>
				<div id='innerHeaderText'>Pending Requests</div>
			";
			echo "<p>The following people have requested to join your team.  You can accept or reject their request.</p>";
			
			while($row=mysql_fetch_array($res))
			{
				echo "<div class='empCell'>";
				echo "<table border='0'>";
            	echo "<tr><td width='400px'>";
//            fName mInit. lName, Job Post
				echo $row['fname']." ".$row['minit']." ".$row['lname'].", ".$row['jobtitle'];
				echo "</td><td><a href='manApprove.php?eid=".$row['eid']."&amp;approve=y'>";
            	echo "<img src='Images/Approve.png' class='button'/></a>
				<a href=\"manApprove.php?eid=".$row['eid'].";approve=n\"><img src='Images/Reject.png' class='button' action='manApprove.php?eid=".$row['eid']."&amp;approve=n'/> </a>";
            	echo "</td></tr>
            </table>
        </div>";
			}
		echo "</div>";
		}
	
		
        
		
		
		?>
    <!-- -->
    
    
	<!-- Insert php loop to print members here, if any. Otherwise, print the no-members div-->
       <?php
	   
		$query="select fname,minit,lname,jobtitle,eid from employee where mid LIKE '".$_SESSION['mid']."' AND mempending=0;";
		
		$res=mysql_query($query);
		if($res && mysql_num_rows($res) != 0)
		{
		echo "<div class='box' id='empList'>
			<div id='innerHeaderText'>Your Team Members</div>";
			while($row=mysql_fetch_array($res))
			{
        		echo "<div class='empCell'>
            <table border='0'>
            <tr><td width='380px'>";
			echo $row['fname']." ".$row['minit']." ".$row['lname'].", ".$row['jobtitle'];
           // fName mInit. lName, Job Post
            echo "</td><td align='right'>
            <div class='statusCell' id='Status1'>##</div><div class='statusCell' id='Status2'>##</div><a href=\"manViewAvail.php?eid=".$row['eid']."\"><img src='Images/Details.png' class='button' style='margin: 6px 5px;' /></a><a href=\"remove.php?eid=".$row['eid'] ."\"><img src=\"Images/Remove.png\" class='button' style='margin: 6px 5px;' /></a>
            </td></tr>
            </table>
        </div>";
			}
		echo "</div>";
		} else {
		
		echo "
			<div class='box' id='empList'>
			<p>You currently have no team members. Please ask your employees to register using your manager ID. Once you've approved a member, their details will appear here.</p>
		";	
			
		}
		?>
        <!-- -->
	</div>
    <div class="footer">
        <form>
            <input type="button" class="button" value= "Create Station" />
            <input type="button" class="button" value= "Join Station" />
            <input type="button" class="button" value= "Leave Station" />
        </form>
    </div>

<?php
mysql_close($con);
?>
</body>
</html>