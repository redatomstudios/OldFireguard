<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.:: FlameGuard ::.</title>
</head>

<body>
<?php
$uname=$_POST['uname'];
$pass=$_POST['pass'];
include ('mysql_include.php');

$empman="none";
$unamepresent=0;
$check=0;
$code="";

$query="select uname,ecode,fname,eid,ecode from employee";
$res=mysql_query($query);
//echo "<br />Check in employee";
while($row=mysql_fetch_array($res))
{
	if($row['uname']==$uname)
	{
		$unamepresent=1;
		$eid=$row['eid'];
		$fname=$row['fname'];
		$code=$row['ecode'];
		break;
	}
}
if($unamepresent)
{
	//echo "<br />Present in employee";
	$query="select * from epassword";
	$res=mysql_query($query);
	
	while($row=mysql_fetch_array($res))						//PROBLEM HERE
	if($row['pass']==$pass)
	{
		//echo "<br />Employee password match";
		$empman="employee";
		break;
	}
	if($empman!="employee") {
		//echo "<br />Wrong Password!!";
		echo "
		<div style='position: absolute; left: 0; top: 0; right: 0; bottom: 0; margin: auto; height: 80px; width: 350px; border: solid 10px #CCf; border-radius: 15px; box-shadow: inset 0 1px 15px #777; padding: 50px 15px; text-align: center; font-weight: bold; font-size: 14px; font-family:Verdana, Geneva, sans-serif;'>
Login failed due to incorrect username or password!
<a href='index.php' onclick='history.back(); return false;' style='position: relative; float: none; display: block; margin-top: 20px;'><img src='Images/Back.png' /></a>
</div>
		";
	}
	
}

if($empman=="none")
{
	//echo "<br />Not Present in employee..Checking manager";
	$unamepresent=0;
$query="select uname,mcode,fname,mid from manager";
$res=mysql_query($query);
while($row=mysql_fetch_array($res))
{
	if($row['uname']==$uname)
	{
		$unamepresent=1;
		$mid=$row['mid'];
		$fname=$row['fname'];
		$code=$row['mcode'];
		break;
	}
}
if($unamepresent)
{
	//echo "<br />Username present in manager";
	$query="select pass from mpassword;";
	$res=mysql_query($query);
	
	while($row=mysql_fetch_array($res))
	if($row['pass']==$pass)
	{
		//echo "<br />Manager password match";
		$empman="manager";
		break;
	}
	if($empman!="manager") {
		//echo "<br />Wrong Password!!";
		echo "
		<div style='position: absolute; left: 0; top: 0; right: 0; bottom: 0; margin: auto; height: 80px; width: 350px; border: solid 10px #CCf; border-radius: 15px; box-shadow: inset 0 1px 15px #777; padding: 50px 15px; text-align: center; font-weight: bold; font-size: 14px; font-family:Verdana, Geneva, sans-serif;'>
Login failed due to incorrect username or password!
<a href='index.php' onclick='history.back(); return false;' style='position: relative; float: none; display: block; margin-top: 20px;'><img src='Images/Back.png' /></a>
</div>
		";
	}
	
}
}

if($empman=="none") {
	//echo "<br />Wrong username";
		echo "
		<div style='position: absolute; left: 0; top: 0; right: 0; bottom: 0; margin: auto; height: 80px; width: 350px; border: solid 10px #CCf; border-radius: 15px; box-shadow: inset 0 1px 15px #777; padding: 50px 15px; text-align: center; font-weight: bold; font-size: 14px; font-family:Verdana, Geneva, sans-serif;'>
Login failed due to incorrect username or password!
<a href='index.php' onclick='history.back(); return false;' style='position: relative; float: none; display: block; margin-top: 20px;'><img src='Images/Back.png' /></a>
</div>
		";
}
else
{
	session_start();
	$_SESSION['name']=$fname;
	$_SESSION['uname']=$uname;

	if($empman=="manager")
	{
		$_SESSION['mid']=$mid;
		header("Location: manControl.php");
		$_SESSION['code']=$mcode;
	}
     else if($empman=="employee")
	 {
		 $_SESSION['eid']=$eid;
		 	$_SESSION['code']=$ecode;
		header("Location: empControl.php");
	 }
}
?>
</body>
</html>