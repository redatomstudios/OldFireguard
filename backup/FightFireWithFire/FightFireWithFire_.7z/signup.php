<?php include("header_ext.php"); ?>
<link href="signup.css" type="text/css" rel="stylesheet" />
<div class="selectionContainer">
<div id="headerText">Create an Account</div>
	<div class="innerBox" id="fLeft">
    	<a href="manSignup.php"><img src="Images/CMA.png" /></a>
        <p></p>
        <br />A manager account will allow you to:
        <ul  style="text-align: left;">
        	<li>Create and manage a squad</li>
            <li>Manager squad members</li>
            <li>View squad member availability</li>
            <li>Assign tasks to squad members</li>
        </ul>
    </div>
	<div class="innerBox" id="fRight">
    	<a href="empSignup.php"><img src="Images/CEA.png" /></a>
        <p></p>
        <br />An employee account will allow you to:
        <ul  style="text-align: left;">
        	<li>Join a squad created by your manager</li>
            <li>Update your status and availability</li>
            <li>View other members in your squad</li>
            <li>View any assigned tasks</li>
        </ul>
    </div>
</div>
</body>
</html>
