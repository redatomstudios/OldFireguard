<html>
<head>
<title>Manager register</title>
<?php

$flag=1;		//CHECKS IF VALID DATA ADDED

$f=1;
if(!($_POST['jTitle']&&$_POST['uName']&&$_POST['eMail']&&$_POST['fName']&&$_POST['lName']&&$_POST['mId']))
	$f=0;
	
if(!$f)
{
	$flag=0;
	//echo "<br>All mandatory values not set";
}

$jtitle=$_POST['jTitle'];
$uname=$_POST['uName'];  
$email=$_POST['eMail'];	
$fname=$_POST['fName'];	
$minit=$_POST['mInit'];
$lname=$_POST['lName']; 
$mid=$_POST['mId']; 

//CHECK IF MANAGER ID PRESENT IN DATABASE
$mcode="";
include ('mysql_include.php');
$query="Select mid,mcode from manager where mid = '".$mid."';";
$res=mysql_query($query);
while($row=mysql_fetch_array($res))
	if($row['mid']==$mid)
		$mcode=$row['mcode'];
if($mcode=="")
{	//echo "<br>NO manager found with dis code<br><br>";
$flag=0;
}
//else
// echo "<br>Manager found with id: ".$mid."<br>Manager code : ".$mcode;

//MANAGER CHECK OVER

function getRandom($size,$base)				//RANDOM HEX VALUE GENERATION FUNCTION
{
	$s="";
	$val;
	for($i=0;$i<$size;$i++)
	{
		$val=(rand()%($base));
		if($val>9)
		{
			switch($val)
			{
				case 10:
				$val="a";
				break;
				case 11:
				$val="b";
				break;
				case 12:
				$val="c";
				break;
				case 13:
				$val="d";
				break;
				case 14:
				$val="e";
				break;
				case 15:
				$val="f";
				break;
				default:
				//echo "Random value > 15 :(";
				break;
			}
			
		}
		$s=$s.$val;
	}
	//echo "<br>Random generated hex value: ".$s;
	return $s;
}		//Random function

function search($mcode,$column,$table)					//SEARCH VALUES IN DATABASE FUNCTION
{
	include ('mysql_include.php');
	$query="select ".$column." from ".$table;
	$res=mysql_query($query);
	while($row = mysql_fetch_array($res))
	{
		if($row[$column]==$mcode)
				 return 1;
	}	
	mysql_close($con);
	return 0;
}


?>
</head>
<body>
<?php 
//echo (rand()%16);   RANDOM FUNCTION
if($flag==1)
{
//echo "<br>Username : ".$uname;
$ifecode=1;
$ifeid=1;
//echo "<br>Employee Code Selection ";
while($ifecode)
{
	
	$ecode=getRandom(10,16);
	 $ifecode=search($ecode,"ecode","employee");
	//echo "<br>Employee code : ".$ecode;
}
//echo "<br>Employee ID Selection ";
while($ifeid)
{
	
	$eid=getRandom(5,16);
	 $ifeid=search($eid,"eid","employee");
	//echo "<br><br>Employee ID : ".$eid;
	}
//echo "<br>Password Selection ";
$pass="password";
$pass=getRandom(6,16);
//echo "<br><br>Password : ".$pass;

	
//VALIDATION
//----------




//USERNAME VALIDATION

//echo "<br>username validation";

if(!(strlen($uname)>6)&&(strlen($uname)<15))
{
	//echo "<br>Username should be greater than 6 and less than 15";
	$flag=0;
}
for($i=0;$i<strlen($uname);$i++)
if(!(ctype_alnum($uname[$i])||$uname[$i]!='_'))
{
	//echo "<br>not alnum!!";
	$flag=0;
}
 $ifuname=search($uname,"uname","employee");
 if($ifuname)
{
//	echo "<br>Username already used!!";
	$flag=0;
}
else
{
	$ifuname=search($uname,"uname","manager");
	if($ifuname)
	{
	//	echo "<br>Username already used!!";
		$flag=0;
	}
}
if($flag)
//echo "<br>Valid username :)";

//echo "<br>FLAG = ".$flag;


//EMAIL VALIDATION

//echo "<br>EMail Verification";


$i=0;
if($email=="")
 {//echo "<br>Email not entered";
 $flag=0;
 }
if($flag==1&&$email[$i]=='.')
{
	//echo "<br>cant start with a .";
	$flag=0;
}
for($i=0;$i<strlen($email)&&$email[$i]!='@'&&$flag==1;$i++)
{
//	echo "<br>".$email[$i];
	if(!(ctype_alnum($email[$i])||$email[$i]=='.'||$email[$i]=='_'))
	{
	//	echo "Special chars not allowed";
		$flag=0;
		break;
	}

	
}
if($i==strlen($email)&&$flag==1)
	{
		//echo "<br>Error : @ missing";
		$flag=0;
	
	}
if($i!=strlen($email)&&$flag==1)
{
for($i=$i+1;$i<strlen($email)&&$email[$i]!='.';$i++)
{
//	echo "<br>".$email[$i];
	if(!(ctype_alnum($email[$i])))
	{
	//	echo "Special chars not allowed";
		$flag=0;
		break;
	}
}
if($i==strlen($email)&&$flag==1)
	{
		//echo "<br>Error : . missing";
		$flag=0;	}

if($i!=strlen($email)&&$flag==1)
for($i=$i+1;$i<strlen($email[$i]);$i++)
{
	if(!(ctype_alnum($email[$i])))
	{
//		echo "Special chars not allowed";
		$flag=0;
		break;
	}
}
}
//echo "<br>FLAG = ".$flag;
//echo "<br>EMail Verification over";
//EMAIL VALIDATION OVER

//FIRST NAME VALIDATION

if(strlen($fname)>15||strlen($fname)<2)
	{
		$flag=0;
	//	echo "<br>Check firstname size";
	}
for($i=0;$i<strlen($fname);$i++)
	if(!(ctype_alpha($fname[$i])))
	{		 
	$flag=0;
	//echo "<br>First name is not all alphabet!!";
	break;
	}

//echo "<br>FLAG = ".$flag;
//echo "<br>First name validation over";

//LAST NAME VALIDATION

if(strlen($lname)>25)
{
	//echo "<br>Last name size = ".strlen($lname);
		$flag=0;
//	echo "<br>Check lastname size";
}
for($i=0;$i<strlen($lname);$i++)
	if(!(ctype_alpha($lname[$i])))
	{		 
		$flag=0;
	//echo "<br>Last name is not all alphabet!!";
	break;
	}

//echo "<br>FLAG = ".$flag;
//echo "<br>Last name validation over";


//jOB TITLE VALIDATION

if(strlen($jtitle)>25||strlen($jtitle)<2)
{
	$flag=0;
//	echo "<br>Job Title size(".strlen($jtitle).") not allowed";
}
for($i=0;$i<strlen($jtitle);$i++)
	if((!(ctype_alnum($jtitle[$i])))||($jtitle[$i]==' '))
	{		 
	//echo "<br>Squad name is not all alphanmeric!!";
	$flag=0;
	break;
	}
//echo "<br>FLAG = ".$flag;
//Middle INITIAL VALIDATION
if(!ctype_alpha($minit)&&$minit!="")
{//	echo "<br>Middle initial not alphabet";
$flag=0;
}
//echo "<br>FLAG = ".$flag;

$regpending=1;
$mempending=1;
//echo "<br><br>TITLE : ".$jtitle."<br>MANAGER CODE : ".$mcode."<br>EMPLOYEE CODE : ".$ecode."<br>EMPLOYEE ID : ".$eid."<br>F NAME ".$fname."<br>M INIT".$minit."<br>L NAME ".$lname."<br>EMAIL ".$email."<br>USERNAME ".$uname."<br>REGISTRATION PENGING ".$regpending."<br>MEMBERSHIP PENDING ".$mempending."<br>MANAGER ID ".$mid."<br>";
if($flag)
{
	
	
	
	//echo "<br>Manager ID:".$mid;
mail($email, "Firefighting test mail", $pass,  "From:".$email);
include ('mysql_include.php');
$query="insert into employee values('".$jtitle."','".$mcode."','".$ecode."','".$eid."','".$fname."','".$minit."','".$lname."','".$email."','".$uname."',".$regpending.",".$mempending.",'".$mid."','0','0','0','0');";
$res=mysql_query($query);
if($res)
{$query="insert into epassword values('".$ecode."','".$pass."');";
mysql_query($query);
$q="insert into availability values ('".$ecode."',";
for($i=0;$i<167;$i++)
{
	$q=$q."0,";
}$q=$q."0);";
mysql_query($q);

echo "<div style='position: absolute; left: 0; top: 0; right: 0; bottom: 0; margin: auto; height: 80px; width: 350px; border: solid 10px #CCf; border-radius: 15px; box-shadow: inset 0 1px 15px #777; padding: 50px 15px; text-align: center; font-weight: bold; font-size: 14px; font-family:Verdana, Geneva, sans-serif;'>
Registration Successful! A temprary password has been sent to your email, please use it to confirm your email address.
<a href='index.php' onclick='history.back(); return false;' style='position: relative; float: none; display: block; margin-top: 20px;'><img src='Images/Back.png' /></a></div>";
}mysql_close($con);
}
}		//IF FLAG EQUALS 1



?>
</body>
</html>