<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>View Per Day</title>
</head>

<body>
<?php
/*if($_SESSION['eid'];
{
	$q="select mid from employee where eid='".$_SESSION['eid']."';";
	$res=mysql_query($q);
	$row=mysql_fetch_array($res);
	$mid=$row['mid'];
}
if($_SESSION['mid'])
	$mid=$_SESSION['mid'];*/
	
$mid='9efc5';
	
switch(date("D"))
{
	case "Sun":
	{
		$day=0;
		break;
	}
	case "Mon":
	{
		$day=1;
		break;
	}
	case "Tue":
	{
		$day=2;
		break;
	}
	case "Wed":
	{
		$day=3;
		break;
	}
	case "Thu":
	{
		$day=4;
		break;
	}
	case "Fri":
	{
		$day=5;
		break;
	}
	case "Sat":
	{
		$day=6;
		break;
	}
	default:
	break;
}
echo "<br />Day: ".date("D")." Value: ".$day;

include ( 'mysql_include.php' );

$q="select scode,mcode from manager where mid='".$mid."';";
$res=mysql_query($q);
$row=mysql_fetch_array($res);
$scode=$row['scode'];
$mcode=$row['mcode'];
//echo "<br />mid: ".$mid."<br />mcode: ".$mcode."scode: ".$row['scode'];
$q="select managers from station where scode='".$scode."';";

$res=mysql_query($q);
$row=mysql_fetch_array($res);
$managers=$row['managers'];

echo "<br />Managers:".$managers;
if($managers=='0')
{
	echo "<br />No other managers in this squad!!";
}

else
{
	
	$man="";
	for($i=0;$i<strlen($managers);$i++)
	{
		if($managers[$i]!=',')
		$man=$man.$managers[$i];
		else	//SEPARATOR REACHED FOR MANAGERS
		{
			echo "<br /><b>Manager code:".$man."</b>";
			
				$q="select eid,ecode from employee where mcode='".$man."';";
				$res=mysql_query($q);
				if($res)
				while($row=mysql_fetch_array($res))
				{
					$eid=$row['eid'];
					echo "<br />Emp id:".$eid."<br />";
					$q="select ";
					for($i=0;$i<23;$i++)
					{
						$q=$q."d".$day."h".$i.",";						
					}
					$q=$q."d".$day."h".$i." ";						
					$q=$q."from availability where ecode='".$row['ecode']."';";
					$res1=mysql_query($q);
					$row1=mysql_fetch_array($res1);
					for($i=0;$i<24;$i++)
					{
						echo $row1['d'.$day.'h'.$i]." ";
					}
					
				}
			
			
			$man="";
		}
	}
}

$q="select owner from station where scode='".$scode."';";
$res=mysql_query($q);
$row=mysql_fetch_array($res);
$man=$row['owner'];
echo "<br /><br /><b><h2>Viewing Owner of the Station..</h2>ManagerCode:".$man."</b>";

	$q="select eid,ecode from employee where mcode='".$man."';";
	$res=mysql_query($q);
	$count=1;
	if($res)
	while( $row = mysql_fetch_array($res) )
	{
		echo "<br />Employee no:".$count;
		$eid=$row['eid'];
		echo " Emp id:".$eid."<br />";
		$q="select ";
		for($i=0;$i<23;$i++)
		{
			$q=$q."d".$day."h".$i.",";						
		}
		$q=$q."d".$day."h".$i." ";						
		$q=$q."from availability where ecode='".$row['ecode']."';";
		$res1=mysql_query($q);
		//echo "<br />".$q."<br />";
		$row1=mysql_fetch_array($res1);
		for($i=0;$i<24;$i++)
		{
			echo $row1['d'.$day.'h'.$i]." ";
		}
		$count++;
		
	}



mysql_close($con);
?>


</body>
</html>