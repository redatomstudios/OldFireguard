<?php include("header.php"); 
if($_SESSION['eid']!=0)
header("Location: index.php");
?>
<link href="ControlPanel.css" rel="stylesheet">
<div class="bodyContainer">
<div id="headerText">Manager Control Panel</div>
<p>
Welcome <?php 
echo $_SESSION['name'].",";
echo "<br />Manager ID: ".$_SESSION['mid'];

?>
</p>

	<?php
    
    include ('mysql_include.php');
	$q="update employee set regpending=0 where mid='".$_SESSION['mid']."';";
	mysql_query($q);
    $query="select fname,minit,lname,jobtitle,eid from employee where mid LIKE '".$_SESSION['mid']."' AND mempending=1;";
    $res=mysql_query($query);
    if($res && mysql_num_rows($res) != 0)
    { 
			echo "<div class='box' id='empApprove'>
				<div id='innerHeaderText'>Pending Requests</div>
			";
			echo "<p>The following people have requested to join your team.  You can accept or reject their request.</p>";
			
			while($row=mysql_fetch_array($res))
			{
				echo "<div class='empCell'>";
				echo "<table border='0'>";
            	echo "<tr><td width='400px'>";
//            fName mInit. lName, Job Post
				echo $row['fname']." ".$row['minit']." ".$row['lname'].", ".$row['jobtitle'];
				echo "</td><td><a href='manApprove.php?eid=".$row['eid']."&amp;approve=y'>";
            	echo "<img src='Images/Approve.png' class='button'/></a>
				<a href=\"manApprove.php?eid=".$row['eid'].";approve=n\"><img src='Images/Reject.png' class='button' action='manApprove.php?eid=".$row['eid']."&amp;approve=n'/> </a>";
            	echo "</td></tr>
            </table>
        </div>";
			}
		echo "</div>";
		}
	
		
        
		
		
		?>
    <!-- -->
    
    
	<!-- Insert php loop to print members here, if any. Otherwise, print the no-members div-->
       <?php
	   
		$query="select fname,minit,lname,jobtitle,eid from employee where mid LIKE '".$_SESSION['mid']."' AND mempending=0;";
		
		$res=mysql_query($query);
		if($res && mysql_num_rows($res) != 0)
		{
		echo "<div class='box' id='empList'>
			<div id='innerHeaderText'>Your Team Members</div>
			<table border='0'><tr><td>
				<div class='vertical' style='margin-left: 360px;'>Driver</div>
				<div class='vertical'>Medic</div>
				<div class='vertical'>Fighter</div>
				<div class='vertical'>Rescue</div>
			</td></tr></table>
			";
			while($row=mysql_fetch_array($res))
			{
        		echo "<div class='empCell'>
            <table border='0'>
			<tr><td width='360px'>";
			echo $row['fname']." ".$row['minit']." ".$row['lname'].", ".$row['jobtitle'];

            echo "</td><td align='right'>
            <div class='statusCell' id='" . /*Echo Status1 for 1 and Status2 for 0 here*/"Status1" . "'></div>
			<div class='statusCell' id='" . /*Echo Status1 for 1 and Status2 for 0 here*/"Status2" . "'></div>
			<div class='statusCell' id='" . /*Echo Status1 for 1 and Status2 for 0 here*/"Status1" . "'></div>
			<div class='statusCell' id='" . /*Echo Status1 for 1 and Status2 for 0 here*/"Status2" . "'></div>
			<a href=\"manViewAvail.php?eid=".$row['eid']."\"><img src='Images/Details.png' class='button' style='margin: 6px 5px;' /></a><a href=\"remove.php?eid=".$row['eid'] ."\"><img src=\"Images/Remove.png\" class='button' style='margin: 6px 5px;' /></a>
            </td></tr>
            </table>
        </div>";
			}
		echo "</div>";
		} else {
		
		echo "
			<div class='box' id='empList'>
			<p>You currently have no team members. Please ask your employees to register using your manager ID. Once you've approved a member, their details will appear here.</p>
		";	
			
		}
		?>
        <!-- -->
	</div>
    <div class="footer">
    <?php
    $q="select scode from manager where mid='".$_SESSION['mid']."';";
	$res=mysql_query($q);
	$row=mysql_fetch_array($res);
	if($row['scode']=='0') {
		echo "
			<form>
				<input type='button' class='button' value= 'Create Station' onclick='triggerFunction(1)' />		
				<input type='button' class='button' value= 'Join Station' onclick='triggerFunction(2)' />
			</form>
		";
	} else if($row['scode']!='1'){
		$_SESSION['scode']=$row['scode'];
		echo "
			<form>
				<input type='button' class='formButton' value= 'Leave Station' onclick='triggerFunction(3)' />
			</form>
		";
	}
	else
	echo "The station you joined have been removed by its owner..";
        ?>
    </div>
	<div class="dialog" id="confirmation">
    	Are you sure you want to leave your station? You can request to join another station after leaving.
        <a href="station_leave.php"><img class="button_spaced" id="accept_confirmation_leave" src="Images/Yes.png" /></a><img class="button_spaced" id="decline_confirmation_leave" src="Images/No.png" onclick="decline()" />
    </div>
    <div class="dialog" id="newStation">
    	Station Name: <form method="post" action="station_register.php" >  <input type="text" name="statName" /><input type="submit" class="button_spaced" value="Create" /><input type="button" class="button_spaced" value="Cancel" onclick="decline()"/></form>
    </div>
    <div class="dialog" id="joinStation">
    	Station ID: <form method="post" action="station_join.php">
    	  <input type="text" name="statID" />
    	  <input type="submit" class="button_spaced" value="Create" /><input type="button" class="button_spaced" value="Cancel" onclick="decline()"/></form>
    </div>
<?php
mysql_close($con);
?>
</div>
<div id="hider"></div>
</body>
</html>